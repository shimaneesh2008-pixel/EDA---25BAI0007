# Digital Distraction and Study Habits — Extended ML Project

## Features
- Streamlit dashboard and column-by-column EDA
- Random Forest grade prediction with MAE, RMSE, and R² evaluation
- **Hyperparameter tuning:** RandomizedSearchCV chooses Random Forest settings using 3-fold cross-validation on the training split and compares tuned results against the original model on a held-out test split
- SHAP explanations for individual grade predictions
- Isolation Forest habit anomaly detection
- **Student Habit Risk Score:** a transparent, rule-based 0–100 indicator built from selected screen-use, study, sleep, focus, attendance, and stress measures. It includes per-student explanations and CSV export.
- Add, edit, and delete student records

## Run in VS Code
1. Keep `app.py`, `requirements.txt`, and `student_productivity_distraction_dataset_20000.csv` in the same folder.
2. Open a terminal in that folder.
3. Install packages: `py -m pip install -r requirements.txt`
4. Run: `py -m streamlit run app.py`

## Important interpretation notes
The Habit Risk Score is an experimental, rule-based indicator, not a validated academic, medical, or psychological risk measure. Its thresholds and weights are illustrative and should be validated before real-world use. Higher scores mean more selected indicators crossed the chosen thresholds; they do not mean that a student will fail or receive a low grade.

Hyperparameter tuning can reduce MAE/RMSE when useful predictive signal exists, but improvement is not guaranteed. If the available variables contain little information about final grades, no algorithm setting can reliably solve that limitation. SHAP explains the model prediction but does not prove causation or improve accuracy by itself. Isolation Forest flags unusual profiles relative to this dataset; unusual does not automatically mean harmful. Keep the MAE, RMSE, and R² visible when presenting grade predictions.

The app saves add/edit/delete operations directly to the CSV. Back up the dataset before changing records.
