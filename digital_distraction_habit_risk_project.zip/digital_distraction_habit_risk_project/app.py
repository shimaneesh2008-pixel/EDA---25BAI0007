from pathlib import Path
import warnings
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor, IsolationForest
from sklearn.model_selection import RandomizedSearchCV
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

warnings.filterwarnings("ignore", category=FutureWarning)
st.set_page_config(page_title="Digital Distraction vs Study Habits", page_icon="📚", layout="wide")

DATASET_PATH = Path(__file__).parent / "student_productivity_distraction_dataset_20000.csv"
TARGET = "final_grade"
ID_COL = "student_id"
EXCLUDED = {ID_COL, TARGET, "productivity_score"}
NUMERIC_FIELDS = {
    "age": (10, 100, 20, 1),
    "study_hours_per_day": (0.0, 24.0, 4.0, 0.5),
    "sleep_hours": (0.0, 24.0, 7.0, 0.5),
    "phone_usage_hours": (0.0, 24.0, 3.0, 0.5),
    "social_media_hours": (0.0, 24.0, 1.5, 0.5),
    "youtube_hours": (0.0, 24.0, 1.0, 0.5),
    "gaming_hours": (0.0, 24.0, 0.5, 0.5),
    "breaks_per_day": (0, 50, 3, 1),
    "coffee_intake_mg": (0, 3000, 0, 25),
    "exercise_minutes": (0, 1440, 20, 5),
    "assignments_completed": (0, 1000, 5, 1),
    "attendance_percentage": (0.0, 100.0, 80.0, 1.0),
    "stress_level": (0, 10, 5, 1),
    "focus_score": (0, 100, 60, 1),
}

st.markdown("""<style>.block-container{padding-top:1.5rem;max-width:1400px}[data-testid="stMetric"]{background:rgba(128,128,128,.08);padding:12px;border-radius:10px}</style>""", unsafe_allow_html=True)

if not DATASET_PATH.exists():
    st.error(f"Dataset not found: {DATASET_PATH.name}. Put the CSV beside app.py.")
    st.stop()

@st.cache_data(show_spinner=False)
def load_data(path_string, modified_time):
    frame = pd.read_csv(path_string)
    frame.columns = [str(c).strip().lower() for c in frame.columns]
    return frame

@st.cache_resource(show_spinner="Tuning and training grade prediction model...")
def train_model(path_string, modified_time):
    frame = load_data(path_string, modified_time).copy()
    frame[TARGET] = pd.to_numeric(frame[TARGET], errors="coerce")
    training = frame.dropna(subset=[TARGET]).copy()
    features = [c for c in training.columns if c not in EXCLUDED and training[c].notna().any()]
    if len(training) < 30 or not features:
        raise ValueError("At least 30 rows with known final grades are required to tune the prediction model.")
    X, y = training[features].copy(), training[TARGET]
    categorical = [c for c in features if not pd.api.types.is_numeric_dtype(X[c])]
    numeric = [c for c in features if c not in categorical]
    transformers = []
    if numeric:
        transformers.append(("numeric", Pipeline([("imputer", SimpleImputer(strategy="median"))]), numeric))
    if categorical:
        transformers.append(("categorical", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("encoder", OneHotEncoder(handle_unknown="ignore"))]), categorical))
    preprocess = ColumnTransformer(transformers, remainder="drop")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.2, random_state=42)

    # Baseline model gives a fair reference point on the same held-out test set.
    baseline_model = Pipeline([("preprocess", preprocess), ("regressor", RandomForestRegressor(
        n_estimators=160, random_state=42, min_samples_leaf=2, n_jobs=-1
    ))])
    baseline_model.fit(X_train, y_train)
    baseline_pred = baseline_model.predict(X_test)
    baseline_metrics = {
        "MAE": mean_absolute_error(y_test, baseline_pred),
        "RMSE": np.sqrt(mean_squared_error(y_test, baseline_pred)),
        "R²": r2_score(y_test, baseline_pred),
    }

    # Tune only on the training portion with cross-validation; the test set is held out
    # until final evaluation. This may improve errors, but cannot guarantee it.
    tuning_model = Pipeline([("preprocess", preprocess), ("regressor", RandomForestRegressor(
        random_state=42, n_jobs=-1
    ))])
    search = RandomizedSearchCV(
        tuning_model,
        param_distributions={
            "regressor__n_estimators": [120, 200, 300],
            "regressor__max_depth": [None, 8, 14, 20],
            "regressor__min_samples_leaf": [1, 2, 4, 6, 10],
            "regressor__max_features": [1.0, "sqrt", 0.7],
        },
        n_iter=8,
        scoring="neg_mean_absolute_error",
        cv=3,
        random_state=42,
        n_jobs=1,
        refit=True,
    )
    search.fit(X_train, y_train)
    tuned_model = search.best_estimator_
    tuned_pred = tuned_model.predict(X_test)
    tuned_metrics = {
        "MAE": mean_absolute_error(y_test, tuned_pred),
        "RMSE": np.sqrt(mean_squared_error(y_test, tuned_pred)),
        "R²": r2_score(y_test, tuned_pred),
        "test_rows": len(y_test),
        "baseline_MAE": baseline_metrics["MAE"],
        "baseline_RMSE": baseline_metrics["RMSE"],
        "baseline_R²": baseline_metrics["R²"],
        "best_params": search.best_params_,
        "cv_MAE": -search.best_score_,
    }
    # Refit selected hyperparameters on all known-grade records for app predictions.
    tuned_model.fit(X, y)
    return training, features, tuned_model, tuned_metrics

def median_or(data, col, fallback):
    if col in data:
        vals = pd.to_numeric(data[col], errors="coerce").dropna()
        if not vals.empty:
            return float(vals.median())
    return float(fallback)

def predict_row(row, features, model, data):
    values = {}
    for col in features:
        if col in row.index and pd.notna(row[col]):
            values[col] = row[col]
        elif col in data and pd.api.types.is_numeric_dtype(data[col]):
            values[col] = pd.to_numeric(data[col], errors="coerce").median()
        else:
            modes = data[col].dropna().mode() if col in data else pd.Series(dtype=object)
            values[col] = modes.iloc[0] if len(modes) else "Unknown"
    return float(model.predict(pd.DataFrame([values], columns=features))[0])

modified_time = DATASET_PATH.stat().st_mtime
try:
    data, features, model, metrics = train_model(str(DATASET_PATH), modified_time)
    all_data = load_data(str(DATASET_PATH), modified_time)
except Exception as exc:
    st.error(f"Could not load data or train model: {exc}")
    st.stop()

st.title("Digital Distraction vs Study Habits")
st.caption("Explore all student records, inspect one student, predict a grade, or add a new student record. No login is required.")

# Top-level counts use all rows, including newly added rows whose actual grade is not yet known.
total_students = len(all_data)
known_grades = pd.to_numeric(all_data.get(TARGET, pd.Series(dtype=float)), errors="coerce").notna().sum()
avg_grade = pd.to_numeric(all_data.get(TARGET, pd.Series(dtype=float)), errors="coerce").mean()
avg_study = pd.to_numeric(all_data.get("study_hours_per_day", pd.Series(dtype=float)), errors="coerce").mean()

m1, m2, m3, m4 = st.columns(4)
m1.metric("Total student records", f"{total_students:,}")
m2.metric("Records with actual grade", f"{known_grades:,}")
m3.metric("Average actual grade", f"{avg_grade:.2f}" if pd.notna(avg_grade) else "N/A")
m4.metric("Average study hours/day", f"{avg_study:.2f}" if pd.notna(avg_study) else "N/A")

tab_overview, tab_analysis, tab_student, tab_manage, tab_add, tab_model, tab_anomaly, tab_risk = st.tabs(["Overall dashboard", "Column-by-column analysis", "View one student / Predict", "Edit / Delete student", "Add student data", "Model evaluation", "Habit anomaly detection", "Student habit risk score"])

with tab_overview:
    st.subheader("Dataset overview")
    c1, c2 = st.columns([1.2, 1])
    with c1:
        st.markdown("**Student records**")
        preview_cols = [c for c in [ID_COL, "age", "gender", "study_hours_per_day", "phone_usage_hours", "focus_score", TARGET] if c in all_data.columns]
        st.dataframe(all_data[preview_cols], use_container_width=True, hide_index=True, height=380)
        st.download_button("Download all student data (CSV)", all_data.to_csv(index=False).encode("utf-8"), "student_data.csv", "text/csv")
    with c2:
        st.markdown("**Average daily activity (hours)**")
        activity_cols = [("study_hours_per_day", "Study"), ("phone_usage_hours", "Phone"), ("social_media_hours", "Social media"), ("youtube_hours", "YouTube/video"), ("gaming_hours", "Gaming")]
        chart_rows = []
        for col, label in activity_cols:
            if col in all_data:
                value = pd.to_numeric(all_data[col], errors="coerce").mean()
                if pd.notna(value): chart_rows.append({"Activity": label, "Hours/day": value})
        if chart_rows:
            chart = pd.DataFrame(chart_rows).set_index("Activity")
            st.bar_chart(chart)
        if "final_grade" in all_data and "study_hours_per_day" in all_data:
            scatter = all_data[["study_hours_per_day", "final_grade"]].apply(pd.to_numeric, errors="coerce").dropna()
            if len(scatter):
                fig, ax = plt.subplots(figsize=(6, 3.5))
                ax.scatter(scatter["study_hours_per_day"], scatter["final_grade"], alpha=.25)
                ax.set_xlabel("Study hours/day"); ax.set_ylabel("Final grade"); ax.set_title("Study time vs actual grade")
                fig.tight_layout(); st.pyplot(fig); plt.close(fig)


with tab_analysis:
    st.subheader("Column-by-column analysis")
    st.write("Explore numeric relationships, category-level grade differences, distributions, and data quality. Charts use the current CSV data.")

    numeric_data = all_data.select_dtypes(include=[np.number]).copy()
    # Convert numeric-looking object columns too, but only when most non-null values parse as numbers.
    for col in all_data.columns:
        if col not in numeric_data.columns:
            converted = pd.to_numeric(all_data[col], errors="coerce")
            non_null_count = all_data[col].notna().sum()
            if non_null_count and converted.notna().sum() / non_null_count >= 0.9:
                numeric_data[col] = converted

    st.markdown("### 1. Dataset column summary")
    summary_rows = []
    for col in all_data.columns:
        series = all_data[col]
        numeric_series = pd.to_numeric(series, errors="coerce")
        is_numeric = numeric_series.notna().sum() > 0 and (pd.api.types.is_numeric_dtype(series) or numeric_series.notna().sum() / max(series.notna().sum(), 1) >= 0.9)
        row = {
            "Column": col,
            "Data type": str(series.dtype),
            "Non-missing": int(series.notna().sum()),
            "Missing": int(series.isna().sum()),
            "Unique values": int(series.nunique(dropna=True)),
        }
        if is_numeric:
            row.update({"Mean": numeric_series.mean(), "Median": numeric_series.median(), "Minimum": numeric_series.min(), "Maximum": numeric_series.max()})
        else:
            row.update({"Mean": np.nan, "Median": np.nan, "Minimum": np.nan, "Maximum": np.nan})
        summary_rows.append(row)
    st.dataframe(pd.DataFrame(summary_rows), use_container_width=True, hide_index=True)

    st.markdown("### 2. Correlation heatmap — all numeric columns")
    if len(numeric_data.columns) >= 2:
        corr = numeric_data.corr(numeric_only=True)
        fig, ax = plt.subplots(figsize=(max(8, len(corr.columns) * 0.65), max(5, len(corr.columns) * 0.55)))
        image = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1, aspect="auto")
        ax.set_xticks(range(len(corr.columns))); ax.set_xticklabels(corr.columns, rotation=90, fontsize=8)
        ax.set_yticks(range(len(corr.index))); ax.set_yticklabels(corr.index, fontsize=8)
        fig.colorbar(image, ax=ax, label="Pearson correlation")
        ax.set_title("Numeric feature correlation matrix")
        fig.tight_layout(); st.pyplot(fig); plt.close(fig)
        st.caption("Correlation ranges from -1 to +1. It measures linear association, not causation.")
    else:
        st.info("At least two numeric columns are needed for a correlation heatmap.")

    st.markdown("### 3. Which numeric columns relate most to final grade?")
    if TARGET in numeric_data.columns:
        grade_corr = numeric_data.corr(numeric_only=True)[TARGET].drop(labels=[TARGET], errors="ignore").dropna()
        grade_corr = grade_corr.reindex(grade_corr.abs().sort_values(ascending=False).index)
        if not grade_corr.empty:
            st.dataframe(grade_corr.rename("Correlation with final grade").to_frame(), use_container_width=True)
            fig, ax = plt.subplots(figsize=(8, max(3, 0.35 * len(grade_corr))))
            grade_corr.sort_values().plot(kind="barh", ax=ax)
            ax.set_xlabel("Pearson correlation with final grade"); ax.set_ylabel("Column")
            ax.set_title("Numeric columns vs final grade")
            fig.tight_layout(); st.pyplot(fig); plt.close(fig)
        else:
            st.info("No usable numeric columns are available to compare with final grade.")
    else:
        st.info("The dataset has no final_grade column.")

    st.markdown("### 4. Compare any two numeric columns")
    if len(numeric_data.columns) >= 2:
        compare_cols = list(numeric_data.columns)
        default_x = compare_cols.index("study_hours_per_day") if "study_hours_per_day" in compare_cols else 0
        default_y = compare_cols.index(TARGET) if TARGET in compare_cols else min(1, len(compare_cols) - 1)
        c1, c2 = st.columns(2)
        x_col = c1.selectbox("X-axis column", compare_cols, index=default_x, key="analysis_x")
        y_col = c2.selectbox("Y-axis column", compare_cols, index=default_y, key="analysis_y")
        pair = numeric_data[[x_col, y_col]].dropna()
        if x_col == y_col:
            st.info("Choose two different columns to compare.")
        elif pair.empty:
            st.warning("No rows have values for both selected columns.")
        else:
            pair_corr = pair[x_col].corr(pair[y_col])
            st.metric(f"Correlation: {x_col} vs {y_col}", f"{pair_corr:.3f}" if pd.notna(pair_corr) else "N/A")
            fig, ax = plt.subplots(figsize=(7, 4))
            hb = ax.hexbin(pair[x_col], pair[y_col], gridsize=30, mincnt=1, cmap="Blues")
            fig.colorbar(hb, ax=ax, label="Number of records")
            ax.set_xlabel(x_col.replace("_", " ").title()); ax.set_ylabel(y_col.replace("_", " ").title())
            ax.set_title(f"{x_col} vs {y_col}")
            fig.tight_layout(); st.pyplot(fig); plt.close(fig)

    st.markdown("### 5. Compare categories")
    categorical_cols = [c for c in all_data.columns if c not in numeric_data.columns and all_data[c].nunique(dropna=True) <= 30]
    if categorical_cols and TARGET in all_data.columns:
        cat_col = st.selectbox("Categorical column", categorical_cols, key="analysis_category")
        category_frame = pd.DataFrame({cat_col: all_data[cat_col].astype("string"), TARGET: pd.to_numeric(all_data[TARGET], errors="coerce")}).dropna()
        if not category_frame.empty:
            grouped = category_frame.groupby(cat_col, dropna=False)[TARGET].agg(["count", "mean", "median"]).reset_index()
            grouped.columns = [cat_col, "Student count", "Average grade", "Median grade"]
            st.dataframe(grouped.sort_values("Average grade", ascending=False), use_container_width=True, hide_index=True)
            fig, ax = plt.subplots(figsize=(8, 4))
            grouped.plot(kind="bar", x=cat_col, y="Average grade", legend=False, ax=ax)
            ax.set_ylabel("Average final grade"); ax.set_xlabel(cat_col.replace("_", " ").title())
            ax.set_title(f"Average final grade by {cat_col}"); plt.xticks(rotation=30, ha="right")
            fig.tight_layout(); st.pyplot(fig); plt.close(fig)
        else:
            st.info("No known grades are available for the selected categories.")
    else:
        st.info("No suitable categorical columns or final_grade column were found.")

    st.markdown("### 6. Distribution of each numeric column")
    if len(numeric_data.columns):
        distribution_col = st.selectbox("Choose a numeric column", list(numeric_data.columns), key="analysis_distribution")
        values = numeric_data[distribution_col].dropna()
        if not values.empty:
            fig, ax = plt.subplots(figsize=(7, 3.5))
            ax.hist(values, bins=30, edgecolor="white")
            ax.set_xlabel(distribution_col.replace("_", " ").title()); ax.set_ylabel("Number of records")
            ax.set_title(f"Distribution of {distribution_col}")
            fig.tight_layout(); st.pyplot(fig); plt.close(fig)

    st.markdown("### 7. Data quality checks")
    dq1, dq2, dq3 = st.columns(3)
    dq1.metric("Duplicate rows", f"{int(all_data.duplicated().sum()):,}")
    dq2.metric("Missing cells", f"{int(all_data.isna().sum().sum()):,}")
    dq3.metric("Columns", f"{len(all_data.columns):,}")
    missing_table = all_data.isna().sum().rename("Missing values").to_frame()
    missing_table["Missing %"] = (missing_table["Missing values"] / max(len(all_data), 1) * 100).round(2)
    st.dataframe(missing_table.sort_values("Missing values", ascending=False), use_container_width=True)

with tab_student:
    st.subheader("Find a student by ID")
    if ID_COL not in all_data.columns:
        st.error("The dataset does not contain a student_id column.")
    else:
        ids = all_data[ID_COL].dropna().astype(str).unique().tolist()
        chosen_id = st.selectbox("Select student ID", options=ids) if ids else None
        if chosen_id is not None:
            matches = all_data[all_data[ID_COL].astype(str) == chosen_id]
            if len(matches) > 1:
                st.warning("This ID appears more than once. Showing the first matching record.")
            student = matches.iloc[0]
            st.markdown(f"### Student ID: {chosen_id}")
            left, right = st.columns([1, 1])
            with left:
                display_row = student.to_frame("Value")
                st.dataframe(display_row, use_container_width=True)
            with right:
                grade = pd.to_numeric(pd.Series([student.get(TARGET, np.nan)]), errors="coerce").iloc[0]
                predicted = predict_row(student, features, model, data)
                p1, p2 = st.columns(2)
                p1.metric("Predicted grade", f"{predicted:.2f}")
                p2.metric("Actual grade", f"{grade:.2f}" if pd.notna(grade) else "Not entered", delta=f"{grade-predicted:+.2f}" if pd.notna(grade) else None)
                st.caption("The prediction is generated from this student's available habit fields. It is an estimate, not a guaranteed result.")
                st.markdown("**Habit snapshot**")
                habit_cols = [("Study hours", "study_hours_per_day"), ("Phone hours", "phone_usage_hours"), ("Sleep hours", "sleep_hours"), ("Focus score", "focus_score"), ("Attendance %", "attendance_percentage")]
                habit_rows = [{"Measure": label, "Value": student.get(col, np.nan)} for label, col in habit_cols if col in student.index]
                if habit_rows: st.dataframe(pd.DataFrame(habit_rows), use_container_width=True, hide_index=True)

                st.divider()
                st.markdown("### Explain this prediction (SHAP Explainable AI)")
                st.caption("SHAP estimates how each model input contributes to this prediction relative to the model baseline. Contributions describe the model, not cause-and-effect relationships.")
                if st.button("Explain selected student's prediction", key="explain_student_prediction"):
                    try:
                        import shap
                        from scipy import sparse

                        # Build one raw feature row in exactly the training feature order.
                        explain_input = pd.DataFrame([{
                            col: student[col] if col in student.index else np.nan
                            for col in features
                        }], columns=features)
                        preprocess = model.named_steps["preprocess"]
                        regressor = model.named_steps["regressor"]
                        transformed = preprocess.transform(explain_input)
                        if sparse.issparse(transformed):
                            transformed = transformed.toarray()
                        else:
                            transformed = np.asarray(transformed)

                        try:
                            feature_names = preprocess.get_feature_names_out().tolist()
                        except Exception:
                            feature_names = [f"Feature {i + 1}" for i in range(transformed.shape[1])]

                        explainer = shap.TreeExplainer(regressor)
                        shap_values = explainer.shap_values(transformed)
                        values = np.asarray(shap_values)
                        if values.ndim == 3:
                            values = values[0, :, 0]
                        elif values.ndim == 2:
                            values = values[0]
                        base_value = np.asarray(explainer.expected_value).reshape(-1)[0]

                        explanation = shap.Explanation(
                            values=values,
                            base_values=float(base_value),
                            data=transformed[0],
                            feature_names=feature_names,
                        )
                        st.write("**How to read it:** features pushing the prediction higher appear on one side; features pushing it lower appear on the other. The baseline is the model's average expected output.")
                        shap.plots.waterfall(explanation, max_display=12, show=False)
                        st.pyplot(plt.gcf(), clear_figure=True)
                        plt.close("all")
                        top_features = pd.DataFrame({
                            "Feature": feature_names,
                            "SHAP contribution": values,
                            "Absolute contribution": np.abs(values),
                        }).sort_values("Absolute contribution", ascending=False).head(12)
                        st.markdown("**Largest feature contributions for this student**")
                        st.dataframe(top_features[["Feature", "SHAP contribution"]].round(4), use_container_width=True, hide_index=True)
                    except ImportError:
                        st.error("SHAP is not installed. Install it in your project environment with: python -m pip install shap")
                    except Exception as exc:
                        st.error(f"Could not create the SHAP explanation: {exc}")


with tab_manage:
    st.subheader("Edit or delete a student record")
    st.warning("Changes are saved directly to the CSV dataset. ")
    if ID_COL not in all_data.columns or all_data.empty:
        st.error("A student_id column and at least one student record are required.")
    else:
        manage_ids = all_data[ID_COL].dropna().astype(str).unique().tolist()
        manage_id = st.selectbox("Choose a student", manage_ids, key="manage_student_id")
        if manage_id:
            match_indices = all_data.index[all_data[ID_COL].astype(str) == manage_id].tolist()
            if len(match_indices) > 1:
                st.error("This student ID occurs more than once. Editing/deleting by ID is disabled to avoid changing the wrong record. Fix duplicate IDs in the CSV first.")
            else:
                row_index = match_indices[0]
                current = all_data.loc[row_index]
                st.markdown(f"**Selected student ID:** `{manage_id}`")
                with st.form("edit_student_form"):
                    st.markdown("#### Edit student details")
                    edits = {}
                    edit_cols = st.columns(3)
                    editable_cols = [c for c in all_data.columns if c != ID_COL]
                    for i, col in enumerate(editable_cols):
                        with edit_cols[i % 3]:
                            value = current[col]
                            if pd.api.types.is_numeric_dtype(all_data[col]) or pd.to_numeric(pd.Series([value]), errors="coerce").notna().all() and pd.notna(value):
                                numeric_series = pd.to_numeric(all_data[col], errors="coerce").dropna()
                                default = float(value) if pd.notna(value) else (float(numeric_series.median()) if not numeric_series.empty else 0.0)
                                if col == TARGET:
                                    edits[col] = st.number_input(f"{col.replace('_', ' ').title()} (blank not supported here; use 0 if unknown)", value=float(default), key=f"edit_{col}")
                                elif float(default).is_integer():
                                    edits[col] = st.number_input(col.replace("_", " ").title(), value=int(default), step=1, key=f"edit_{col}")
                                else:
                                    edits[col] = st.number_input(col.replace("_", " ").title(), value=float(default), step=0.5, key=f"edit_{col}")
                            else:
                                options = all_data[col].dropna().astype(str).unique().tolist()
                                current_text = str(value) if pd.notna(value) else ""
                                if current_text and current_text not in options:
                                    options.insert(0, current_text)
                                if not options:
                                    options = [current_text or "Not specified"]
                                edits[col] = st.selectbox(col.replace("_", " ").title(), options, index=options.index(current_text) if current_text in options else 0, key=f"edit_{col}")
                    save_edits = st.form_submit_button("Save changes", type="primary", use_container_width=True)
                if save_edits:
                    for col, value in edits.items():
                        all_data.at[row_index, col] = value
                    all_data.to_csv(DATASET_PATH, index=False)
                    load_data.clear()
                    train_model.clear()
                    st.success(f"Student {manage_id} was updated.")
                    st.rerun()

                st.divider()
                st.markdown("#### Delete student record")
                confirm_delete = st.checkbox(f"I confirm that I want to permanently delete student {manage_id} from the local CSV.", key=f"confirm_delete_{manage_id}")
                if st.button("Delete selected student", type="secondary", disabled=not confirm_delete, key=f"delete_{manage_id}", use_container_width=True):
                    remaining = all_data[all_data[ID_COL].astype(str) != manage_id].copy()
                    remaining.to_csv(DATASET_PATH, index=False)
                    load_data.clear()
                    train_model.clear()
                    st.success(f"Student {manage_id} was deleted.")
                    st.rerun()

with tab_add:
    st.subheader("Add a student record")
    st.write("New records are appended to the local CSV so they remain available after restarting the app. Leave actual grade blank if it is not known yet.")
    with st.form("add_student_form", clear_on_submit=True):
        student_id = st.text_input("Student ID", placeholder="e.g. STU20001")
        age = st.number_input("Age", 10, 100, 20, 1)
        gender = st.selectbox("Gender", sorted(all_data["gender"].dropna().astype(str).unique().tolist()) if "gender" in all_data and all_data["gender"].notna().any() else ["Not specified"])
        c1, c2, c3 = st.columns(3)
        with c1:
            study = st.number_input("Study hours/day", 0.0, 24.0, 4.0, .5)
            sleep = st.number_input("Sleep hours/day", 0.0, 24.0, 7.0, .5)
            phone = st.number_input("Phone usage hours/day", 0.0, 24.0, 3.0, .5)
            social = st.number_input("Social media hours/day", 0.0, 24.0, 1.5, .5)
            youtube = st.number_input("YouTube/video hours/day", 0.0, 24.0, 1.0, .5)
        with c2:
            gaming = st.number_input("Gaming hours/day", 0.0, 24.0, .5, .5)
            breaks = st.number_input("Breaks/day", 0, 50, 3, 1)
            coffee = st.number_input("Coffee intake (mg/day)", 0, 3000, 0, 25)
            exercise = st.number_input("Exercise minutes/day", 0, 1440, 20, 5)
            assignments = st.number_input("Assignments completed", 0, 1000, 5, 1)
        with c3:
            attendance = st.number_input("Attendance (%)", 0.0, 100.0, 80.0, 1.0)
            stress = st.number_input("Stress level (0–10)", 0, 10, 5, 1)
            focus = st.number_input("Focus score (0–100)", 0, 100, 60, 1)
            actual_grade_text = st.text_input("Actual final grade (optional)", placeholder="Leave blank if unknown")
        save = st.form_submit_button("Add student record", type="primary", use_container_width=True)
    if save:
        sid = student_id.strip()
        if not sid:
            st.error("Enter a student ID.")
        elif all_data[ID_COL].astype(str).str.strip().str.casefold().eq(sid.casefold()).any():
            st.error("That student ID already exists. Choose a unique ID.")
        else:
            grade_value = np.nan
            if actual_grade_text.strip():
                try:
                    grade_value = float(actual_grade_text)
                    if not 0 <= grade_value <= 100: raise ValueError
                except ValueError:
                    st.error("Actual final grade must be a number from 0 to 100, or left blank.")
                    st.stop()
            new_record = {
                "student_id": sid, "age": age, "gender": gender,
                "study_hours_per_day": study, "sleep_hours": sleep,
                "phone_usage_hours": phone, "social_media_hours": social,
                "youtube_hours": youtube, "gaming_hours": gaming,
                "breaks_per_day": breaks, "coffee_intake_mg": coffee,
                "exercise_minutes": exercise, "assignments_completed": assignments,
                "attendance_percentage": attendance, "stress_level": stress,
                "focus_score": focus, "final_grade": grade_value,
                "productivity_score": np.nan,
            }
            # Keep exactly the existing dataset columns and order.
            new_frame = pd.DataFrame([{col: new_record.get(col, np.nan) for col in all_data.columns}])
            updated = pd.concat([all_data, new_frame], ignore_index=True)
            updated.to_csv(DATASET_PATH, index=False)
            load_data.clear(); train_model.clear()
            st.success(f"Student {sid} was added to the dataset. Refreshing the app will include the new record.")
            st.info("If the actual grade is blank, the record counts toward total students but is excluded from model training until a grade is available.")
            st.rerun()

with tab_model:
    st.subheader("Prediction model evaluation")
    e1, e2, e3, e4 = st.columns(4)
    e1.metric("MAE", f"{metrics['MAE']:.3f}")
    e2.metric("RMSE", f"{metrics['RMSE']:.3f}")
    e3.metric("R²", f"{metrics['R²']:.3f}")
    e4.metric("Test records", f"{metrics['test_rows']:,}")
    st.markdown("### Hyperparameter tuning comparison")
    comparison = pd.DataFrame([
        {"Model": "Original Random Forest", "MAE": metrics["baseline_MAE"], "RMSE": metrics["baseline_RMSE"], "R²": metrics["baseline_R²"]},
        {"Model": "Tuned Random Forest", "MAE": metrics["MAE"], "RMSE": metrics["RMSE"], "R²": metrics["R²"]},
    ])
    st.dataframe(comparison.round(3), use_container_width=True, hide_index=True)
    mae_change = metrics["baseline_MAE"] - metrics["MAE"]
    rmse_change = metrics["baseline_RMSE"] - metrics["RMSE"]
    c1, c2 = st.columns(2)
    c1.metric("MAE change vs original", f"{mae_change:+.3f}", help="Positive means the tuned model reduced MAE; negative means it increased MAE.")
    c2.metric("RMSE change vs original", f"{rmse_change:+.3f}", help="Positive means the tuned model reduced RMSE; negative means it increased RMSE.")
    st.caption("The search selects hyperparameters using 3-fold cross-validation on the training split. Test-set results are reported separately. Tuning may not improve results when the available features have little predictive signal.")
    with st.expander("Best hyperparameters selected"):
        st.json(metrics["best_params"])
        st.write(f"Cross-validation MAE during tuning: {metrics['cv_MAE']:.3f}")
    if metrics["R²"] < 0:
        st.error("R² is below zero on this test split. The model performed slightly worse than predicting the test-set average.")
    elif metrics["R²"] < .3:
        st.warning("R² is low. Treat predictions as experimental and do not describe them as highly accurate.")
    st.caption("The model trains only on records with known final_grade values. MAE and RMSE are measured in the dataset's grade units. Predictions do not prove that digital usage causes changes in grades.")
with tab_anomaly:
    st.subheader("Personalized Habit Anomaly Detection")
    st.write(
        "This analysis flags student habit profiles that are unusual compared with the dataset. "
        "It uses Isolation Forest and does not use final grades to decide whether a profile is unusual."
    )
    st.caption(
        "An anomaly is not automatically a bad habit or a sign of academic failure. "
        "This is a screening signal for review, not a diagnosis or causal conclusion."
    )

    habit_candidates = [
        "study_hours_per_day", "sleep_hours", "phone_usage_hours",
        "social_media_hours", "youtube_hours", "gaming_hours",
        "breaks_per_day", "coffee_intake_mg", "exercise_minutes",
        "assignments_completed", "attendance_percentage", "stress_level", "focus_score"
    ]
    habit_cols = [c for c in habit_candidates if c in all_data.columns]
    if len(habit_cols) < 2 or len(all_data) < 10:
        st.warning("At least two habit columns and ten student records are required for anomaly detection.")
    else:
        habit_frame = all_data[habit_cols].apply(pd.to_numeric, errors="coerce")
        usable_cols = [c for c in habit_frame.columns if habit_frame[c].notna().any() and habit_frame[c].nunique(dropna=True) > 1]
        habit_frame = habit_frame[usable_cols]
        if len(usable_cols) < 2:
            st.warning("Not enough variable numeric habit columns are available.")
        else:
            contamination_pct = st.slider(
                "Expected percentage of unusual profiles", min_value=1, max_value=10, value=5, step=1,
                help="This controls how many profiles the algorithm is expected to flag; it is not an observed risk rate."
            )
            prepared = habit_frame.fillna(habit_frame.median()).fillna(0)
            detector = IsolationForest(
                n_estimators=150, contamination=contamination_pct / 100, random_state=42, n_jobs=-1
            )
            labels = detector.fit_predict(prepared)
            anomaly_scores = -detector.decision_function(prepared)
            results = all_data.copy()
            results["Habit profile status"] = np.where(labels == -1, "Unusual profile", "Typical profile")
            results["Anomaly score"] = anomaly_scores

            a1, a2, a3 = st.columns(3)
            a1.metric("Records analyzed", f"{len(results):,}")
            a2.metric("Unusual profiles flagged", f"{int((labels == -1).sum()):,}")
            a3.metric("Habit features used", f"{len(usable_cols)}")

            show_cols = [c for c in [ID_COL, "Habit profile status", "Anomaly score"] + usable_cols + [TARGET] if c in results.columns]
            st.markdown("#### Student habit profile results")
            st.dataframe(
                results[show_cols].sort_values("Anomaly score", ascending=False).round(3),
                use_container_width=True, hide_index=True
            )
            st.download_button(
                "Download anomaly results (CSV)",
                results[show_cols].sort_values("Anomaly score", ascending=False).to_csv(index=False).encode("utf-8"),
                "student_habit_anomaly_results.csv", "text/csv"
            )

            if ID_COL in all_data.columns and all_data[ID_COL].notna().any():
                ids_for_anomaly = all_data[ID_COL].dropna().astype(str).tolist()
                chosen_anomaly_id = st.selectbox("Inspect a student's habit profile", ids_for_anomaly, key="anomaly_student_id")
                row_matches = all_data.index[all_data[ID_COL].astype(str) == chosen_anomaly_id].tolist()
                if row_matches:
                    idx = row_matches[0]
                    status = results.iloc[idx]["Habit profile status"]
                    st.markdown(f"**Status: {status}**")
                    # Show robust standardized deviations as descriptive clues, not causal explanations.
                    row_values = prepared.iloc[idx]
                    medians = prepared.median()
                    mads = (prepared - medians).abs().median().replace(0, np.nan)
                    deviations = ((row_values - medians) / (1.4826 * mads)).replace([np.inf, -np.inf], np.nan).dropna()
                    if not deviations.empty:
                        clue = deviations.abs().sort_values(ascending=False).head(5)
                        clue_table = pd.DataFrame({
                            "Feature": clue.index,
                            "Student value": [row_values[c] for c in clue.index],
                            "Dataset median": [medians[c] for c in clue.index],
                            "Robust deviation (approx.)": [deviations[c] for c in clue.index],
                        })
                        st.markdown("#### Features furthest from typical values")
                        st.dataframe(clue_table.round(3), use_container_width=True, hide_index=True)
                    st.caption("The deviation table provides context for review; it is not a causal explanation of why the algorithm flagged the record.")


with tab_risk:
    st.subheader("Student Habit Risk Score")
    st.write(
        "A transparent, rule-based indicator that summarizes selected habit patterns. "
        "It is separate from the Random Forest grade prediction and does not use final grades to calculate the score."
    )
    st.warning(
        "This is an experimental project score, not a validated academic, medical, or psychological risk measure. "
        "Thresholds are illustrative and should be validated with real student feedback before real-world use."
    )

    risk_weights = {
        "phone_usage_hours": (25, lambda x: np.clip(x / 10.0, 0, 1), "Higher phone use"),
        "study_hours_per_day": (20, lambda x: np.clip((5.0 - x) / 5.0, 0, 1), "Lower study time"),
        "sleep_hours": (20, lambda x: np.clip((7.0 - x) / 7.0, 0, 1), "Less than 7 hours of sleep"),
        "focus_score": (15, lambda x: np.clip((70.0 - x) / 70.0, 0, 1), "Lower focus score"),
        "attendance_percentage": (10, lambda x: np.clip((85.0 - x) / 85.0, 0, 1), "Lower attendance"),
        "stress_level": (10, lambda x: np.clip(x / 10.0, 0, 1), "Higher self-reported stress"),
    }
    available_risk_cols = [c for c in risk_weights if c in all_data.columns]
    if len(available_risk_cols) < 2:
        st.info("At least two of the required habit columns are needed to calculate this score.")
    else:
        st.caption("Formula: weighted sum of normalized indicators, rescaled to 0–100 using only available fields. Higher means more indicators crossed the chosen thresholds; it does not mean a student will receive a low grade.")

        risk_frame = all_data[available_risk_cols].apply(pd.to_numeric, errors="coerce")
        risk_parts = pd.DataFrame(index=all_data.index)
        for col in available_risk_cols:
            weight, transform, _label = risk_weights[col]
            risk_parts[col] = transform(risk_frame[col]) * weight
        weights_available = sum(risk_weights[c][0] for c in available_risk_cols)
        weighted_total = risk_parts.sum(axis=1, min_count=1)
        present_weight = risk_frame.notna().mul(pd.Series({c: risk_weights[c][0] for c in available_risk_cols}), axis=1).sum(axis=1)
        risk_score = (weighted_total / present_weight.replace(0, np.nan) * 100).clip(0, 100)

        def risk_band(score):
            if pd.isna(score):
                return "Insufficient data"
            if score < 34:
                return "Lower indicator level"
            if score < 67:
                return "Moderate indicator level"
            return "Higher indicator level"

        risk_results = pd.DataFrame({
            ID_COL: all_data[ID_COL].astype(str) if ID_COL in all_data.columns else all_data.index.astype(str),
            "Habit risk score (0–100)": risk_score.round(1),
            "Indicator category": risk_score.apply(risk_band),
        }, index=all_data.index)
        for col in available_risk_cols:
            risk_results[col] = risk_frame[col]
        r1, r2, r3 = st.columns(3)
        r1.metric("Students scored", f"{risk_score.notna().sum():,}")
        r2.metric("Average indicator score", f"{risk_score.mean():.1f}" if risk_score.notna().any() else "N/A")
        r3.metric("Higher indicator level", f"{(risk_score >= 67).sum():,}")

        st.markdown("#### Student-level scores")
        st.dataframe(risk_results.sort_values("Habit risk score (0–100)", ascending=False, na_position="last"), use_container_width=True, hide_index=True)
        st.download_button(
            "Download habit risk scores (CSV)",
            risk_results.to_csv(index=False).encode("utf-8"),
            "student_habit_risk_scores.csv", "text/csv"
        )

        if ID_COL in all_data.columns and all_data[ID_COL].notna().any():
            risk_ids = all_data[ID_COL].dropna().astype(str).unique().tolist()
            selected_risk_id = st.selectbox("Inspect a student's score", risk_ids, key="risk_score_student_id")
            matches = all_data.index[all_data[ID_COL].astype(str) == selected_risk_id].tolist()
            if matches:
                idx = matches[0]
                score = risk_score.loc[idx]
                c1, c2 = st.columns([1, 2])
                c1.metric("Habit risk score", f"{score:.1f}/100" if pd.notna(score) else "N/A", help="Higher scores mean more of the selected indicators crossed the illustrative thresholds.")
                c2.write(f"**Category:** {risk_band(score)}")
                contributions = []
                for col in available_risk_cols:
                    value = risk_frame.loc[idx, col]
                    if pd.isna(value):
                        continue
                    weight, transform, label = risk_weights[col]
                    contributions.append({"Indicator": label, "Recorded value": value, "Weighted contribution": float(transform(value) * weight)})
                if contributions:
                    st.markdown("#### Indicators contributing to this score")
                    st.dataframe(pd.DataFrame(contributions).sort_values("Weighted contribution", ascending=False), use_container_width=True, hide_index=True)

# --------------------------------------------------
# CODE EFFICIENCY ANALYSIS
# --------------------------------------------------
import time
import tracemalloc

st.subheader("Code Efficiency Analysis")

if st.button("Measure Data Processing Efficiency"):
    tracemalloc.start()
    start_time = time.perf_counter()

    # Measure a representative data-processing operation
    numeric_data = data.select_dtypes(include="number")
    correlation_matrix = numeric_data.corr()

    elapsed_time = time.perf_counter() - start_time
    _, peak_memory = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    col1, col2, col3 = st.columns(3)

    col1.metric("Processing Time", f"{elapsed_time:.4f} seconds")
    col2.metric("Peak Traced Memory", f"{peak_memory / (1024 ** 2):.2f} MB")
    col3.metric("Dataset Rows", f"{len(data):,}")

    st.caption(
        "These measurements cover the correlation calculation only, "
        "not the entire dashboard or model training."
    )

    st.dataframe(correlation_matrix, use_container_width=True)